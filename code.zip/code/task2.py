from PIL import Image
import json
import numpy as np
path='images/'#图片路径
img=Image.open(path+'2_15.jpg')#读取图片数据
M,N=img.size
region=img.crop((M/2,N/8,5*M/8,2*N/8))
r,g,b=region.split()#分割像素通道
rd=np.asarray(r)
gd=np.asarray(r)
bd=np.asarray(r)
result={'r通道像素矩阵':rd.tolist(),'g通道像素矩阵':gd.tolist(),'b通道像素矩阵':bd.tolist()}

#将字典转成json并存放在文件中
js=open('task2.json','w',encoding='utf-8')
#将字典转换成json
js2=json.dump(result,js,ensure_ascii=False)#ensure_ascii=False将字典中的中文编码转换一下，不然输出时显示的是ASCII码
#从文件中读取json,并转化成字典
js=open('task2.json','r',encoding='utf-8')
dic=json.load(js)
print(dic)
# a=np.array([[1,2,3],[4,5,6],[5,3,7]])
# b=np.array([[6,7,8],[9,10,11],[8,5,9]])
# c=np.array([[3,4,5],[9,0,1],[8,3,7]])
# d={'爱':a.tolist(),'你':b.tolist(),'哟':c.tolist()}
# js=open('a.json','w',encoding='utf-8')
# js2=json.dump(d,js,ensure_ascii=False)

