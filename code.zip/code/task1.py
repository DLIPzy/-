from PIL import Image
path='images/'#图片路径
img=Image.open(path+'2_15.jpg')#读取图片数据
M,N=img.size
print(M,N)
region=img.crop((M/2,N/8,5*M/8,2*N/8))#截取图片有效区域
print(region.size)
ims=[]
#图片转换为相同的尺寸
for i in [img,region]:
    new_img=i.resize((1000,1000),Image.BILINEAR)
    ims.append(new_img)
#单幅图像的尺寸
width,height=ims[0].size
#创建空白长图
result=Image.new(ims[0].mode,(width,height*len(ims)))
#拼接图片
for i,im in enumerate(ims):
    result.paste(im,box=(0,i*height))
#保存图片
result.save('task1.jpg')

