from PIL import Image
import re,os
path = 'images/'
def get_img_names(path):
     file_names=os.listdir(path)#获取path中所有文件
     img_names = []
     #获取所有图片名称
     for i in file_names:
         if re.findall('^\d_\d+\.jpg$',i)!=[]:#找出所有图片
                 img_names.append(i)
     return img_names
print(get_img_names(path))


