import numpy as np
from PIL import Image
import json
path='images/'#图片路径
img=Image.open(path+'2_15.jpg')#读取图片数据
M,N=img.size
region=img.crop((M/2,N/8,5*M/8,2*N/8))
r,g,b=region.split()#分割像素通道
rd=np.asarray(r)
gd=np.asarray(r)
bd=np.asarray(r)
#定义三阶矩函数
def Third_moment(x):
    mid=np.mean((x-x.mean())**3)
    return np.sign(mid)*(abs(mid))**(1/3)
data=Third_moment(rd)
print(data)
