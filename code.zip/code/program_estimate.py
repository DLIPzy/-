from data_process import get_img_data
import numpy as np
import pandas as pd
import json
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report,confusion_matrix
path='images/'
data,labels=get_img_data(path)

#转换为json格式
js1=open('data.json','w',encoding='utf-8')
cla_data=pd.DataFrame(data=data,columns=['r一阶矩','g一阶矩','b一阶矩','r二阶矩','g二阶矩','b二阶矩','r三阶矩','g三阶矩','b三阶矩'])
cla_data.to_json(js1,orient='index',force_ascii=False)
js2=open('lables.json','w',encoding='utf-8')
cla_labels=pd.DataFrame(data=labels,columns=['标签'])
cla_labels.to_json(js2,force_ascii=False)

#数据集划分
data_trian,data_test,labels_train,labels_test=train_test_split(data,labels,test_size=0.2,)#将专家样本拆分为训练集和测试集

#决策树分类
Dtc=DecisionTreeClassifier().fit(data_trian,labels_train)#模型训练
pre=Dtc.predict(data_test)#预测值
#打印混淆矩阵和分类报告
print(confusion_matrix(labels_test,pre))
print(classification_report(labels_test,pre))

#支持向量机分类
model=SVC().fit(data_trian,labels_train)
pre1=model.predict(data_test)
#打印混淆矩阵和分类报告
print(confusion_matrix(labels_test,pre1))
print(classification_report(labels_test,pre1))
